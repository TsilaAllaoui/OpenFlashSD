<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.12.2" name="tiles" tilewidth="8" tileheight="8" tilecount="252" columns="12">
 <image source="../graphics/tiles.bmp" width="96" height="168"/>
</tileset>
