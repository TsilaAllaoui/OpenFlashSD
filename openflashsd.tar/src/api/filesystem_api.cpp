#include "bn_core.h"
#include "mock/mocks.h"
#include "file_browser.h"
#include "filesystem_api.h"

namespace openflash
{
    namespace api
    {
        filesystem_api &api::filesystem_api::instance()
        {
            static filesystem_api api;
            return api;
        }

        bn::vector<file_entry, max_file_count> filesystem_api::get_files(bn::optional<file_type> file_filter)
        {
            auto files =
                mock::mock_file_entries();

            _files.clear();

            for (const auto &file : files)
            {
                if (file_filter.has_value() &&
                    file.type != *file_filter &&
                    file.type != file_type::FOLDER)
                {
                    continue;
                }

                _files.emplace_back(file);
            }

            return _files;
        }
    }
}
