#include "bn_vector.h"
#include "bn_random.h"

#include "cart_api.h"
#include "mock/mocks.h"
#include "file_entry.h"

namespace openflash
{
    namespace api
    {

        namespace
        {
            bn::random cart_random;
        }

        cart_api &cart_api::instance()
        {
            static cart_api api;
            return api;
        }

        void cart_api::request_cart_infos()
        {
            _loading = true;
            _response_ready = false;
            _current_cart_infos.reset();
#ifdef USEMOCK
            _mock_frames = 15;
#endif
        }

        void cart_api::update()
        {
            if (!_loading)
                return;
#ifdef USEMOCK
            if (_mock_frames > 0)
            {
                _mock_frames--;
                return;
            }
#endif

            _current_cart_infos.emplace();

#ifdef USEMOCK
            auto random_rom_infos_index = cart_random.get_int(mock::mock_roms_infos.size());
            auto file = mock::mock_roms_infos[random_rom_infos_index];
            auto header = mock::get_gba_header(file.path);
            _current_cart_infos->cart_rom_infos = mock::get_gba_file_info(header.data());
            _current_cart_infos->name = "M36L0T735";
#else
            // esp32 call here
#endif
            _loading = false;
            _response_ready = true;
        }

        bool cart_api::response_available() const
        {
            return _response_ready && _current_cart_infos.has_value();
        }

        const cart_infos &cart_api::get_cart_infos_response() const
        {
            if (!_current_cart_infos.has_value())
                BN_ERROR("Cart infos is nullopt");
            return *_current_cart_infos;
        }
    }
}
