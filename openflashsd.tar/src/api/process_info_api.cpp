#include "process_info_api.h"
#include "bn_random.h"

namespace openflash
{
    namespace api
    {
        namespace
        {
            bn::random process_random;
        }
        process_info_api::process_info_api()
            : _current_process_infos(),
              _frames(0)
        {
            _current_process_infos.emplace();
            _frames = 0;
            _current_process_infos->progress = 0;
            _current_process_infos->speed = 0;
            _current_process_infos->elapsed_time = {0, 0};
            _current_process_infos->estimated_time = {0, 0};
        }

        process_info_api &process_info_api::instance()
        {
            static process_info_api api;
            return api;
        }

        void process_info_api::request_process_infos()
        {
            _loading = true;
            _response_ready = false;
            if (!_current_process_infos)
                _current_process_infos.emplace();
#ifdef USEMOCK
            _mock_frames = 15;
#endif
        }

        void process_info_api::update()
        {
            if (!_loading)
                return;
#ifdef USEMOCK
            if (_mock_frames > 0)
            {
                _mock_frames--;
                return;
            }

            if (_current_process_infos->progress < 100)
                _current_process_infos->progress++;

            _current_process_infos->speed = process_random.get_int(500);

            _current_process_infos->type = process_type::DUMPING;

            if (_current_process_infos->type == process_type::DUMPING || _current_process_infos->type == process_type::BACKUP_SAVE)
                _current_process_infos->status = process_status::READING;
            else
                _current_process_infos->status = process_status::WRITING;

#else
            _current_process_infos.emplace();
            // call esp32 here
#endif
            _loading = false;
            _response_ready = true;
#ifdef USEMOCK
            _mock_frames = 15;
#endif
        }

        bool process_info_api::response_available() const
        {
            return _response_ready;
        }

        const process_infos &process_info_api::get_process_infos_response() const
        {
            if (!_current_process_infos)
                BN_ERROR("Process infos is nullopt");
            return *_current_process_infos;
        }

        void process_info_api::request_process_infos_reset()
        {
            // call esp32 and reset on server side too
            _current_process_infos.reset();
        }
    }
}
